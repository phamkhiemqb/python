//
//  ViewController.swift
//  TableView
//
//  Created by PK on 4/10/19.
//  Copyright © 2019 PKLovestar. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    
    var data:[Flag] = [Flag(image: "vn.png", nameVi: "Việt Nam", nameEn: "Vietnamese"),
                       Flag(image: "canada.jpg", nameVi: "Canada", nameEn: "Canada"),
                       Flag(image: "jp.png", nameVi: "Nhật Bản", nameEn: "Japanese"),
                       Flag(image: "kr.png", nameVi: "Hàn Quốc", nameEn: "Korea"),
                       Flag(image: "ru.jpg", nameVi: "Nga", nameEn: "Russia"),
                       Flag(image: "us.png", nameVi: "Mỹ", nameEn: "United States")]
    

    @IBOutlet weak var table: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        table.dataSource = self
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL") as! TableViewCell
        cell.imgFag.image = UIImage(named: data[indexPath.row].image)
        cell.txtVn.text = data[indexPath.row].nameVi
        cell.txtEn.text = data[indexPath.row].nameEn
        return cell
    }


}

