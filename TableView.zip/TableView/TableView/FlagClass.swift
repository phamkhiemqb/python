//
//  FlagClass.swift
//  TableView
//
//  Created by PK on 4/10/19.
//  Copyright © 2019 PKLovestar. All rights reserved.
//

import Foundation
class Flag {
    public var image:String
    public var nameVi:String
    public var nameEn:String
    init(image:String, nameVi:String, nameEn:String) {
        self.image = image
        self.nameVi = nameVi
        self.nameEn = nameEn
    }
    
    
}
